﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;

namespace ConsoleApp1
{

	class Program
	{		
		class Product 
		{
			public string productName;
			public double unitPrice;
			public bool appliesTaxes;
			public bool importedProduct;

			public Product(string name, double price, bool tax, bool imported )
			{
				productName = name;
				unitPrice = price;
				appliesTaxes = tax;
				importedProduct = imported;
			}						
		}


		static void Main(string[] args)
		{			
			Console.WriteLine("How many items are on the basket");
			var basket = new List<Product>();
			int numberItems = Convert.ToInt32(Console.ReadLine());
		
			for (int i = 1; i <= numberItems; i++)
			{
				Console.WriteLine("Item Number " + i);
				Console.WriteLine("Product Name");
				string productName = Console.ReadLine();
				Console.WriteLine("Unit Price");
				double price = Convert.ToDouble(Console.ReadLine());
				Console.WriteLine("Is Imported (Y/N)");
				bool importedProduct = false;
				if (Console.ReadLine().ToLower() == "y")
				{
					importedProduct = true;
				}
				Console.WriteLine("Taxes Applies (Y/N)");
				bool taxApplies = false;
				if (Console.ReadLine().ToLower() == "y")
				{
					taxApplies = true;
				}

				Product product = new Product(productName, price, taxApplies, importedProduct);
				basket.Add(product);

				Console.WriteLine(productName + " added to the basket, Click any key to Continue.");
				Console.ReadKey();
				Console.Clear();					
			}

			Console.WriteLine(GetTotal(basket));

			//var basket1 = new List<Product>()
			//{
			//	new Product("Book",12.49,false,false),
			//	new Product("Music CD",14.99,true,false),
			//	new Product("Book",12.49,false,false),
			//	new Product("Chocolate",0.85,false, false)
			//};

			//var basket2 = new List<Product>()
			//{
			//	new Product("Imported box of chocolates",10.00,false,true),
			//	new Product("Imported bottle of perfume",47.50,true,true)			
			//};

			//var basket3 = new List<Product>()
			//{
			//	new Product("Imported box of chocolates",27.99,true, true),
			//	new Product("Bottle of perfume",18.99,true, false),
			//	new Product("Packet of headache pills",9.75,false, false),
			//	new Product("Imported box of chocolates",11.25,false, true),
			//	new Product("Imported box of chocolates",11.25,false, true)			
			//};

			//Console.WriteLine(GetTotal(basket1));
			//Console.WriteLine(GetTotal(basket2));
			//Console.WriteLine(GetTotal(basket3));
		}

		private static string GetTotal(List<Product> basketProducts) 
		{
			double total = 0;
			double taxes = 0;
			string receipt = "";
			

			//LINQ query to group objects and get number of times the item is in the basket.
			var receiptItems = basketProducts.GroupBy(x => new { x.productName, x.unitPrice, x.appliesTaxes, x.importedProduct })
											 .Select(x => new { x.Key.productName, x.Key.unitPrice, x.Key.appliesTaxes,x.Key.importedProduct, Count = x.Count()});


			//Loop items to get sale total
			for (int i = 0; i < receiptItems.Count(); i++)
			{					
				var item = receiptItems.ElementAt(i);
				double finalUnitPrice = GetFinalItemPrice(item.unitPrice, item.importedProduct, item.appliesTaxes);	
				if (item.Count > 1)
				{
					receipt = receipt +  item.productName + " : " + String.Format("{0:0.00}", finalUnitPrice * item.Count) + " (" + item.Count.ToString() + " @ " + String.Format("{0:0.00}", finalUnitPrice) + ")" + "\n";
					total = total + finalUnitPrice * item.Count;
					taxes = taxes + (finalUnitPrice * item.Count) - (item.unitPrice * item.Count);
				}
				else
				{
					receipt = receipt + item.productName + " : " + String.Format("{0:0.00}", finalUnitPrice) + "\n";
					total = total + finalUnitPrice;
					taxes = taxes + finalUnitPrice - item.unitPrice ;
				}
			}

			//Add the total of product and taxes to the string
			receipt = receipt + "Sale Taxes " + String.Format("{0:0.00}", Math.Round(taxes, 2)) + "\n";
			receipt = receipt + "Total " + String.Format("{0:0.00}", total) + "\n";

			return receipt;			

		}


		//Method to obtain the taxes applied to the product in case that applies.
		private static double GetFinalItemPrice(double price, bool isImported, bool appliesTaxes)
		{			
			double importTaxes = 0;
			double regularTaxes = 0;
			string taxes;

			if (isImported)
			{				
				taxes  = String.Format("{0:0.00}", price * 0.05);				
				if (taxes[taxes.Length - 1] != '5')
				{
					importTaxes = Math.Round(price * .05, 1);
				}
				else
				{
					importTaxes = Convert.ToDouble(taxes);
				}
				
			}
			if (appliesTaxes)
			{
				taxes = String.Format("{0:0.00}", price * 0.10);
				if (taxes[taxes.Length - 1] != '5' )
				{
					regularTaxes = Math.Round(price * .10, 1);
				}
				else
				{
					regularTaxes = Convert.ToDouble(taxes);
				}
			}

			return Convert.ToDouble(String.Format("{0:0.00}",(price + importTaxes + regularTaxes)));			
		}

	}
}
